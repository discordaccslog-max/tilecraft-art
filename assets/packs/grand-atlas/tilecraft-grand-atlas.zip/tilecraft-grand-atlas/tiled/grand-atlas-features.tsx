<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Atlas rivers, roads and markers" tilewidth="16" tileheight="16" tilecount="176" columns="16">
 <image source="../sheets/1x/grand-atlas-features.png" width="256" height="176"/>
 <tile id="0"><animation><frame tileid="0" duration="220"/><frame tileid="1" duration="220"/><frame tileid="2" duration="220"/><frame tileid="3" duration="220"/></animation></tile>
 <tile id="4"><animation><frame tileid="4" duration="220"/><frame tileid="5" duration="220"/><frame tileid="6" duration="220"/><frame tileid="7" duration="220"/></animation></tile>
 <tile id="8"><animation><frame tileid="8" duration="220"/><frame tileid="9" duration="220"/><frame tileid="10" duration="220"/><frame tileid="11" duration="220"/></animation></tile>
 <tile id="12"><animation><frame tileid="12" duration="220"/><frame tileid="13" duration="220"/><frame tileid="14" duration="220"/><frame tileid="15" duration="220"/></animation></tile>
 <tile id="16"><animation><frame tileid="16" duration="220"/><frame tileid="17" duration="220"/><frame tileid="18" duration="220"/><frame tileid="19" duration="220"/></animation></tile>
 <tile id="20"><animation><frame tileid="20" duration="220"/><frame tileid="21" duration="220"/><frame tileid="22" duration="220"/><frame tileid="23" duration="220"/></animation></tile>
 <tile id="24"><animation><frame tileid="24" duration="220"/><frame tileid="25" duration="220"/><frame tileid="26" duration="220"/><frame tileid="27" duration="220"/></animation></tile>
 <tile id="28"><animation><frame tileid="28" duration="220"/><frame tileid="29" duration="220"/><frame tileid="30" duration="220"/><frame tileid="31" duration="220"/></animation></tile>
 <tile id="32"><animation><frame tileid="32" duration="220"/><frame tileid="33" duration="220"/><frame tileid="34" duration="220"/><frame tileid="35" duration="220"/></animation></tile>
 <tile id="36"><animation><frame tileid="36" duration="220"/><frame tileid="37" duration="220"/><frame tileid="38" duration="220"/><frame tileid="39" duration="220"/></animation></tile>
 <tile id="40"><animation><frame tileid="40" duration="220"/><frame tileid="41" duration="220"/><frame tileid="42" duration="220"/><frame tileid="43" duration="220"/></animation></tile>
 <tile id="44"><animation><frame tileid="44" duration="220"/><frame tileid="45" duration="220"/><frame tileid="46" duration="220"/><frame tileid="47" duration="220"/></animation></tile>
 <tile id="48"><animation><frame tileid="48" duration="220"/><frame tileid="49" duration="220"/><frame tileid="50" duration="220"/><frame tileid="51" duration="220"/></animation></tile>
 <tile id="52"><animation><frame tileid="52" duration="220"/><frame tileid="53" duration="220"/><frame tileid="54" duration="220"/><frame tileid="55" duration="220"/></animation></tile>
 <tile id="56"><animation><frame tileid="56" duration="220"/><frame tileid="57" duration="220"/><frame tileid="58" duration="220"/><frame tileid="59" duration="220"/></animation></tile>
 <tile id="60"><animation><frame tileid="60" duration="220"/><frame tileid="61" duration="220"/><frame tileid="62" duration="220"/><frame tileid="63" duration="220"/></animation></tile>
 <tile id="94"><animation><frame tileid="94" duration="500"/><frame tileid="95" duration="500"/></animation></tile>
 <tile id="96"><animation><frame tileid="96" duration="300"/><frame tileid="97" duration="300"/></animation></tile>
 <tile id="98"><animation><frame tileid="98" duration="300"/><frame tileid="99" duration="300"/></animation></tile>
 <tile id="100"><animation><frame tileid="100" duration="220"/><frame tileid="101" duration="220"/><frame tileid="102" duration="220"/><frame tileid="103" duration="220"/></animation></tile>
 <tile id="104"><animation><frame tileid="104" duration="220"/><frame tileid="105" duration="220"/><frame tileid="106" duration="220"/><frame tileid="107" duration="220"/></animation></tile>
 <tile id="108"><animation><frame tileid="108" duration="220"/><frame tileid="109" duration="220"/><frame tileid="110" duration="220"/><frame tileid="111" duration="220"/></animation></tile>
 <wangsets>
  <wangset name="River" type="edge" tile="60">
   <wangcolor name="River" color="#4f8eae" tile="60" probability="1"/>
   <wangcolor name="Surroundings" color="#404060" tile="-1" probability="1"/>
   <wangtile tileid="0" wangid="2,0,2,0,2,0,2,0"/>
   <wangtile tileid="4" wangid="1,0,2,0,2,0,2,0"/>
   <wangtile tileid="8" wangid="2,0,1,0,2,0,2,0"/>
   <wangtile tileid="12" wangid="1,0,1,0,2,0,2,0"/>
   <wangtile tileid="16" wangid="2,0,2,0,1,0,2,0"/>
   <wangtile tileid="20" wangid="1,0,2,0,1,0,2,0"/>
   <wangtile tileid="24" wangid="2,0,1,0,1,0,2,0"/>
   <wangtile tileid="28" wangid="1,0,1,0,1,0,2,0"/>
   <wangtile tileid="32" wangid="2,0,2,0,2,0,1,0"/>
   <wangtile tileid="36" wangid="1,0,2,0,2,0,1,0"/>
   <wangtile tileid="40" wangid="2,0,1,0,2,0,1,0"/>
   <wangtile tileid="44" wangid="1,0,1,0,2,0,1,0"/>
   <wangtile tileid="48" wangid="2,0,2,0,1,0,1,0"/>
   <wangtile tileid="52" wangid="1,0,2,0,1,0,1,0"/>
   <wangtile tileid="56" wangid="2,0,1,0,1,0,1,0"/>
   <wangtile tileid="60" wangid="1,0,1,0,1,0,1,0"/>
  </wangset>
  <wangset name="Road" type="edge" tile="79">
   <wangcolor name="Road" color="#a57b50" tile="79" probability="1"/>
   <wangcolor name="Surroundings" color="#404060" tile="-1" probability="1"/>
   <wangtile tileid="64" wangid="2,0,2,0,2,0,2,0"/>
   <wangtile tileid="65" wangid="1,0,2,0,2,0,2,0"/>
   <wangtile tileid="66" wangid="2,0,1,0,2,0,2,0"/>
   <wangtile tileid="67" wangid="1,0,1,0,2,0,2,0"/>
   <wangtile tileid="68" wangid="2,0,2,0,1,0,2,0"/>
   <wangtile tileid="69" wangid="1,0,2,0,1,0,2,0"/>
   <wangtile tileid="70" wangid="2,0,1,0,1,0,2,0"/>
   <wangtile tileid="71" wangid="1,0,1,0,1,0,2,0"/>
   <wangtile tileid="72" wangid="2,0,2,0,2,0,1,0"/>
   <wangtile tileid="73" wangid="1,0,2,0,2,0,1,0"/>
   <wangtile tileid="74" wangid="2,0,1,0,2,0,1,0"/>
   <wangtile tileid="75" wangid="1,0,1,0,2,0,1,0"/>
   <wangtile tileid="76" wangid="2,0,2,0,1,0,1,0"/>
   <wangtile tileid="77" wangid="1,0,2,0,1,0,1,0"/>
   <wangtile tileid="78" wangid="2,0,1,0,1,0,1,0"/>
   <wangtile tileid="79" wangid="1,0,1,0,1,0,1,0"/>
  </wangset>
 </wangsets>
</tileset>
