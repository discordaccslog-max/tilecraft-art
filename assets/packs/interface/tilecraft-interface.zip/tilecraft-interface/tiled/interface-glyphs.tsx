<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Cursors and icons" tilewidth="16" tileheight="16" tilecount="48" columns="16">
 <image source="../sheets/1x/interface-glyphs.png" width="256" height="48"/>
 <tile id="11"><animation><frame tileid="11" duration="120"/><frame tileid="12" duration="120"/><frame tileid="13" duration="120"/><frame tileid="14" duration="120"/></animation></tile>
</tileset>
