<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Interface pieces" tilewidth="16" tileheight="16" tilecount="456" columns="24">
 <image source="../sheets/1x/interface-ui.png" width="384" height="304"/>
 <tile id="107"><animation><frame tileid="107" duration="140"/><frame tileid="108" duration="140"/><frame tileid="109" duration="140"/><frame tileid="110" duration="140"/></animation></tile>
 <tile id="251"><animation><frame tileid="251" duration="140"/><frame tileid="252" duration="140"/><frame tileid="253" duration="140"/><frame tileid="254" duration="140"/></animation></tile>
 <tile id="395"><animation><frame tileid="395" duration="140"/><frame tileid="396" duration="140"/><frame tileid="397" duration="140"/><frame tileid="398" duration="140"/></animation></tile>
</tileset>
