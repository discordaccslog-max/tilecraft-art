<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Ink dungeon" tilewidth="16" tileheight="16" tilecount="96" columns="16">
 <image source="../sheets/1x/ink-edition-dungeon.png" width="256" height="96"/>
 <tile id="0" probability="0"/>
 <tile id="52"><animation><frame tileid="52" duration="700"/><frame tileid="53" duration="90"/><frame tileid="54" duration="90"/><frame tileid="55" duration="600"/></animation></tile>
 <tile id="56"><animation><frame tileid="56" duration="130"/><frame tileid="57" duration="130"/><frame tileid="58" duration="130"/><frame tileid="59" duration="130"/></animation></tile>
 <tile id="60"><animation><frame tileid="60" duration="700"/><frame tileid="61" duration="80"/><frame tileid="62" duration="600"/><frame tileid="63" duration="90"/></animation></tile>
 <wangsets>
  <wangset name="Walls" type="mixed" tile="46">
   <wangcolor name="Walls" color="#262137" tile="46" probability="1"/>
   <wangcolor name="Surroundings" color="#404060" tile="-1" probability="1"/>
   <wangtile tileid="0" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="1" wangid="1,2,2,2,2,2,2,2"/>
   <wangtile tileid="2" wangid="2,2,1,2,2,2,2,2"/>
   <wangtile tileid="3" wangid="1,2,1,2,2,2,2,2"/>
   <wangtile tileid="4" wangid="1,1,1,2,2,2,2,2"/>
   <wangtile tileid="5" wangid="2,2,2,2,1,2,2,2"/>
   <wangtile tileid="6" wangid="1,2,2,2,1,2,2,2"/>
   <wangtile tileid="7" wangid="2,2,1,2,1,2,2,2"/>
   <wangtile tileid="8" wangid="1,2,1,2,1,2,2,2"/>
   <wangtile tileid="9" wangid="1,1,1,2,1,2,2,2"/>
   <wangtile tileid="10" wangid="2,2,1,1,1,2,2,2"/>
   <wangtile tileid="11" wangid="1,2,1,1,1,2,2,2"/>
   <wangtile tileid="12" wangid="1,1,1,1,1,2,2,2"/>
   <wangtile tileid="13" wangid="2,2,2,2,2,2,1,2"/>
   <wangtile tileid="14" wangid="1,2,2,2,2,2,1,2"/>
   <wangtile tileid="15" wangid="2,2,1,2,2,2,1,2"/>
   <wangtile tileid="16" wangid="1,2,1,2,2,2,1,2"/>
   <wangtile tileid="17" wangid="1,1,1,2,2,2,1,2"/>
   <wangtile tileid="18" wangid="2,2,2,2,1,2,1,2"/>
   <wangtile tileid="19" wangid="1,2,2,2,1,2,1,2"/>
   <wangtile tileid="20" wangid="2,2,1,2,1,2,1,2"/>
   <wangtile tileid="21" wangid="1,2,1,2,1,2,1,2"/>
   <wangtile tileid="22" wangid="1,1,1,2,1,2,1,2"/>
   <wangtile tileid="23" wangid="2,2,1,1,1,2,1,2"/>
   <wangtile tileid="24" wangid="1,2,1,1,1,2,1,2"/>
   <wangtile tileid="25" wangid="1,1,1,1,1,2,1,2"/>
   <wangtile tileid="26" wangid="2,2,2,2,1,1,1,2"/>
   <wangtile tileid="27" wangid="1,2,2,2,1,1,1,2"/>
   <wangtile tileid="28" wangid="2,2,1,2,1,1,1,2"/>
   <wangtile tileid="29" wangid="1,2,1,2,1,1,1,2"/>
   <wangtile tileid="30" wangid="1,1,1,2,1,1,1,2"/>
   <wangtile tileid="31" wangid="2,2,1,1,1,1,1,2"/>
   <wangtile tileid="32" wangid="1,2,1,1,1,1,1,2"/>
   <wangtile tileid="33" wangid="1,1,1,1,1,1,1,2"/>
   <wangtile tileid="34" wangid="1,2,2,2,2,2,1,1"/>
   <wangtile tileid="35" wangid="1,2,1,2,2,2,1,1"/>
   <wangtile tileid="36" wangid="1,1,1,2,2,2,1,1"/>
   <wangtile tileid="37" wangid="1,2,2,2,1,2,1,1"/>
   <wangtile tileid="38" wangid="1,2,1,2,1,2,1,1"/>
   <wangtile tileid="39" wangid="1,1,1,2,1,2,1,1"/>
   <wangtile tileid="40" wangid="1,2,1,1,1,2,1,1"/>
   <wangtile tileid="41" wangid="1,1,1,1,1,2,1,1"/>
   <wangtile tileid="42" wangid="1,2,2,2,1,1,1,1"/>
   <wangtile tileid="43" wangid="1,2,1,2,1,1,1,1"/>
   <wangtile tileid="44" wangid="1,1,1,2,1,1,1,1"/>
   <wangtile tileid="45" wangid="1,2,1,1,1,1,1,1"/>
   <wangtile tileid="46" wangid="1,1,1,1,1,1,1,1"/>
  </wangset>
 </wangsets>
</tileset>
