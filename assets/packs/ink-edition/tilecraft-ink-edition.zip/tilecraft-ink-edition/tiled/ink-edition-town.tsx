<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Ink town" tilewidth="16" tileheight="16" tilecount="64" columns="16">
 <image source="../sheets/1x/ink-edition-town.png" width="256" height="64"/>
 <tile id="33"><animation><frame tileid="33" duration="400"/><frame tileid="34" duration="400"/></animation></tile>
 <tile id="49"><animation><frame tileid="49" duration="400"/><frame tileid="50" duration="400"/></animation></tile>
</tileset>
