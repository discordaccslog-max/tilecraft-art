<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Hearthvale props" tilewidth="16" tileheight="16" tilecount="96" columns="16">
 <image source="../sheets/1x/hearthvale-props.png" width="256" height="96"/>
 <tile id="12"><animation><frame tileid="12" duration="180"/><frame tileid="13" duration="180"/><frame tileid="14" duration="180"/><frame tileid="15" duration="180"/></animation></tile>
 <tile id="28"><animation><frame tileid="28" duration="180"/><frame tileid="29" duration="180"/><frame tileid="30" duration="180"/><frame tileid="31" duration="180"/></animation></tile>
 <wangsets>
  <wangset name="Picket fence" type="edge" tile="95">
   <wangcolor name="Picket fence" color="#e9dcbc" tile="95" probability="1"/>
   <wangcolor name="Surroundings" color="#404060" tile="-1" probability="1"/>
   <wangtile tileid="80" wangid="2,0,2,0,2,0,2,0"/>
   <wangtile tileid="81" wangid="1,0,2,0,2,0,2,0"/>
   <wangtile tileid="82" wangid="2,0,1,0,2,0,2,0"/>
   <wangtile tileid="83" wangid="1,0,1,0,2,0,2,0"/>
   <wangtile tileid="84" wangid="2,0,2,0,1,0,2,0"/>
   <wangtile tileid="85" wangid="1,0,2,0,1,0,2,0"/>
   <wangtile tileid="86" wangid="2,0,1,0,1,0,2,0"/>
   <wangtile tileid="87" wangid="1,0,1,0,1,0,2,0"/>
   <wangtile tileid="88" wangid="2,0,2,0,2,0,1,0"/>
   <wangtile tileid="89" wangid="1,0,2,0,2,0,1,0"/>
   <wangtile tileid="90" wangid="2,0,1,0,2,0,1,0"/>
   <wangtile tileid="91" wangid="1,0,1,0,2,0,1,0"/>
   <wangtile tileid="92" wangid="2,0,2,0,1,0,1,0"/>
   <wangtile tileid="93" wangid="1,0,2,0,1,0,1,0"/>
   <wangtile tileid="94" wangid="2,0,1,0,1,0,1,0"/>
   <wangtile tileid="95" wangid="1,0,1,0,1,0,1,0"/>
  </wangset>
 </wangsets>
</tileset>
