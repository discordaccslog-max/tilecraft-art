<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Hearthvale ground" tilewidth="16" tileheight="16" tilecount="112" columns="16">
 <image source="../sheets/1x/hearthvale-terrain.png" width="256" height="112"/>
 <tile id="16" probability="0"/>
 <tile id="64" probability="0"/>
 <wangsets>
  <wangset name="Cobblestone path" type="mixed" tile="62">
   <wangcolor name="Cobblestone path" color="#7f7473" tile="62" probability="1"/>
   <wangcolor name="Surroundings" color="#404060" tile="-1" probability="1"/>
   <wangtile tileid="16" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="17" wangid="1,2,2,2,2,2,2,2"/>
   <wangtile tileid="18" wangid="2,2,1,2,2,2,2,2"/>
   <wangtile tileid="19" wangid="1,2,1,2,2,2,2,2"/>
   <wangtile tileid="20" wangid="1,1,1,2,2,2,2,2"/>
   <wangtile tileid="21" wangid="2,2,2,2,1,2,2,2"/>
   <wangtile tileid="22" wangid="1,2,2,2,1,2,2,2"/>
   <wangtile tileid="23" wangid="2,2,1,2,1,2,2,2"/>
   <wangtile tileid="24" wangid="1,2,1,2,1,2,2,2"/>
   <wangtile tileid="25" wangid="1,1,1,2,1,2,2,2"/>
   <wangtile tileid="26" wangid="2,2,1,1,1,2,2,2"/>
   <wangtile tileid="27" wangid="1,2,1,1,1,2,2,2"/>
   <wangtile tileid="28" wangid="1,1,1,1,1,2,2,2"/>
   <wangtile tileid="29" wangid="2,2,2,2,2,2,1,2"/>
   <wangtile tileid="30" wangid="1,2,2,2,2,2,1,2"/>
   <wangtile tileid="31" wangid="2,2,1,2,2,2,1,2"/>
   <wangtile tileid="32" wangid="1,2,1,2,2,2,1,2"/>
   <wangtile tileid="33" wangid="1,1,1,2,2,2,1,2"/>
   <wangtile tileid="34" wangid="2,2,2,2,1,2,1,2"/>
   <wangtile tileid="35" wangid="1,2,2,2,1,2,1,2"/>
   <wangtile tileid="36" wangid="2,2,1,2,1,2,1,2"/>
   <wangtile tileid="37" wangid="1,2,1,2,1,2,1,2"/>
   <wangtile tileid="38" wangid="1,1,1,2,1,2,1,2"/>
   <wangtile tileid="39" wangid="2,2,1,1,1,2,1,2"/>
   <wangtile tileid="40" wangid="1,2,1,1,1,2,1,2"/>
   <wangtile tileid="41" wangid="1,1,1,1,1,2,1,2"/>
   <wangtile tileid="42" wangid="2,2,2,2,1,1,1,2"/>
   <wangtile tileid="43" wangid="1,2,2,2,1,1,1,2"/>
   <wangtile tileid="44" wangid="2,2,1,2,1,1,1,2"/>
   <wangtile tileid="45" wangid="1,2,1,2,1,1,1,2"/>
   <wangtile tileid="46" wangid="1,1,1,2,1,1,1,2"/>
   <wangtile tileid="47" wangid="2,2,1,1,1,1,1,2"/>
   <wangtile tileid="48" wangid="1,2,1,1,1,1,1,2"/>
   <wangtile tileid="49" wangid="1,1,1,1,1,1,1,2"/>
   <wangtile tileid="50" wangid="1,2,2,2,2,2,1,1"/>
   <wangtile tileid="51" wangid="1,2,1,2,2,2,1,1"/>
   <wangtile tileid="52" wangid="1,1,1,2,2,2,1,1"/>
   <wangtile tileid="53" wangid="1,2,2,2,1,2,1,1"/>
   <wangtile tileid="54" wangid="1,2,1,2,1,2,1,1"/>
   <wangtile tileid="55" wangid="1,1,1,2,1,2,1,1"/>
   <wangtile tileid="56" wangid="1,2,1,1,1,2,1,1"/>
   <wangtile tileid="57" wangid="1,1,1,1,1,2,1,1"/>
   <wangtile tileid="58" wangid="1,2,2,2,1,1,1,1"/>
   <wangtile tileid="59" wangid="1,2,1,2,1,1,1,1"/>
   <wangtile tileid="60" wangid="1,1,1,2,1,1,1,1"/>
   <wangtile tileid="61" wangid="1,2,1,1,1,1,1,1"/>
   <wangtile tileid="62" wangid="1,1,1,1,1,1,1,1"/>
  </wangset>
  <wangset name="Plaza slabs" type="mixed" tile="110">
   <wangcolor name="Plaza slabs" color="#e9dcbc" tile="110" probability="1"/>
   <wangcolor name="Surroundings" color="#404060" tile="-1" probability="1"/>
   <wangtile tileid="64" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="65" wangid="1,2,2,2,2,2,2,2"/>
   <wangtile tileid="66" wangid="2,2,1,2,2,2,2,2"/>
   <wangtile tileid="67" wangid="1,2,1,2,2,2,2,2"/>
   <wangtile tileid="68" wangid="1,1,1,2,2,2,2,2"/>
   <wangtile tileid="69" wangid="2,2,2,2,1,2,2,2"/>
   <wangtile tileid="70" wangid="1,2,2,2,1,2,2,2"/>
   <wangtile tileid="71" wangid="2,2,1,2,1,2,2,2"/>
   <wangtile tileid="72" wangid="1,2,1,2,1,2,2,2"/>
   <wangtile tileid="73" wangid="1,1,1,2,1,2,2,2"/>
   <wangtile tileid="74" wangid="2,2,1,1,1,2,2,2"/>
   <wangtile tileid="75" wangid="1,2,1,1,1,2,2,2"/>
   <wangtile tileid="76" wangid="1,1,1,1,1,2,2,2"/>
   <wangtile tileid="77" wangid="2,2,2,2,2,2,1,2"/>
   <wangtile tileid="78" wangid="1,2,2,2,2,2,1,2"/>
   <wangtile tileid="79" wangid="2,2,1,2,2,2,1,2"/>
   <wangtile tileid="80" wangid="1,2,1,2,2,2,1,2"/>
   <wangtile tileid="81" wangid="1,1,1,2,2,2,1,2"/>
   <wangtile tileid="82" wangid="2,2,2,2,1,2,1,2"/>
   <wangtile tileid="83" wangid="1,2,2,2,1,2,1,2"/>
   <wangtile tileid="84" wangid="2,2,1,2,1,2,1,2"/>
   <wangtile tileid="85" wangid="1,2,1,2,1,2,1,2"/>
   <wangtile tileid="86" wangid="1,1,1,2,1,2,1,2"/>
   <wangtile tileid="87" wangid="2,2,1,1,1,2,1,2"/>
   <wangtile tileid="88" wangid="1,2,1,1,1,2,1,2"/>
   <wangtile tileid="89" wangid="1,1,1,1,1,2,1,2"/>
   <wangtile tileid="90" wangid="2,2,2,2,1,1,1,2"/>
   <wangtile tileid="91" wangid="1,2,2,2,1,1,1,2"/>
   <wangtile tileid="92" wangid="2,2,1,2,1,1,1,2"/>
   <wangtile tileid="93" wangid="1,2,1,2,1,1,1,2"/>
   <wangtile tileid="94" wangid="1,1,1,2,1,1,1,2"/>
   <wangtile tileid="95" wangid="2,2,1,1,1,1,1,2"/>
   <wangtile tileid="96" wangid="1,2,1,1,1,1,1,2"/>
   <wangtile tileid="97" wangid="1,1,1,1,1,1,1,2"/>
   <wangtile tileid="98" wangid="1,2,2,2,2,2,1,1"/>
   <wangtile tileid="99" wangid="1,2,1,2,2,2,1,1"/>
   <wangtile tileid="100" wangid="1,1,1,2,2,2,1,1"/>
   <wangtile tileid="101" wangid="1,2,2,2,1,2,1,1"/>
   <wangtile tileid="102" wangid="1,2,1,2,1,2,1,1"/>
   <wangtile tileid="103" wangid="1,1,1,2,1,2,1,1"/>
   <wangtile tileid="104" wangid="1,2,1,1,1,2,1,1"/>
   <wangtile tileid="105" wangid="1,1,1,1,1,2,1,1"/>
   <wangtile tileid="106" wangid="1,2,2,2,1,1,1,1"/>
   <wangtile tileid="107" wangid="1,2,1,2,1,1,1,1"/>
   <wangtile tileid="108" wangid="1,1,1,2,1,1,1,1"/>
   <wangtile tileid="109" wangid="1,2,1,1,1,1,1,1"/>
   <wangtile tileid="110" wangid="1,1,1,1,1,1,1,1"/>
  </wangset>
 </wangsets>
</tileset>
