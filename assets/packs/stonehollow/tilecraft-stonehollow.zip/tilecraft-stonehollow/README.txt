STONEHOLLOW DUNGEON TILESET
Tilecraft Art

Thank you for your purchase. This pack contains 182 assets (216 frames in
total). All art is pixel art on a 16×16 tile grid.

FOLDER LAYOUT
  assets/1x    every asset as its own PNG at original size (animations as horizontal strips)
  assets/2x    every asset at 2×
  assets/4x    every asset at 4×
  maps         the sample maps rendered as PNG images
  metadata     JSON listing every asset, its sheet position, size, animation frames and timings
  palette      the palette as .hex and .gpl (GIMP, Aseprite, Krita and others)
  sheets/1x    sprite sheets at original size
  sheets/2x    sprite sheets at 2× (nearest-neighbour)
  sheets/4x    sprite sheets at 4× (nearest-neighbour)
  tiled        Tiled tilesets (.tsx) with autotiling terrain sets, and finished sample maps (.tmx)
  LICENSE.txt  the full license
  README.txt   this file

TILE SIZE AND GRID
Tiles are 16×16 pixels. Sheets are laid out on that grid with no spacing or
margins. Larger objects (trees, buildings, effects) span whole multiples of
the grid. Positions in the JSON are given in pixels at 1×; multiply by 2 or 4
for the scaled sheets.

AUTOTILING
Terrain sets use the 47-tile "blob" layout. Each tile's "autotile.mask" in the
JSON is an 8-bit neighbour mask: N=1, NE=2, E=4, SE=8, S=16, SW=32, W=64,
NW=128, where a diagonal only counts when both of its neighbouring sides are
set. To pick a tile, build the mask from a cell's neighbours and find the tile
with that mask. Connection sets (fences, paths, rivers, roads) use a 16-tile
layout with N=1, E=2, S=4, W=8.
The .tsx files include these rules as Tiled terrain sets (Wang sets), so the
Terrain brush in Tiled places the right tiles automatically. Blob terrain
tiles have transparent surroundings, so they can be layered over any ground
tile.

IMPORTING INTO A GAME ENGINE
General: import the 1× sheets and scale your camera or window by whole
numbers, with filtering turned off (nearest-neighbour). Or use the 2× or 4×
files directly.
Godot 4: set the default texture filter to Nearest (Project Settings >
Rendering > Textures). Create a TileSet with a 16×16 tile size from a sheet,
or import the .tmx through a Tiled importer add-on. Use the JSON frames for
AnimatedSprite2D.
Unity: set each sheet's Filter Mode to Point and Compression to None, Sprite
Mode to Multiple, and slice by cell size 16×16 (or 16×32 for characters). Use
the nineSlice values in the JSON as sprite borders for interface pieces.
GameMaker: import sheets as sprites with "Split by grid", or as tile sets with
16×16 tiles. Turn off texture interpolation in the game options.
Tiled: open any .tmx in the tiled folder. Keep the folder structure as it is,
because the .tsx files point to ../sheets/1x/.
Web frameworks (Phaser, PixiJS, LÖVE and others): load a 1× sheet and read
frame rectangles from the JSON; set image smoothing off and use whole-number
scales.
Every engine handles imports a little differently, so please check the files
with your own setup.

HOW THESE ASSETS ARE MADE
The art in these packs was created with AI assistance and drawn
programmatically in code, pixel by pixel. No AI image generators were used,
and no one else's artwork was used or traced.

Some game stores and platforms ask developers to disclose AI-assisted content
in their games. If you publish a game that uses these assets, follow the rules
of the store or platform you publish on.

LICENSE
Use these assets in unlimited games and apps you make, including commercial
ones. No attribution required. Don't resell or redistribute the assets
themselves, use them in logos, trademarks, NFTs or crypto-tokens, or use them
to train AI models. See LICENSE.txt for the full license.

HELP
Lost your key or found a problem? Contact us through the Contact page on the
Tilecraft Art website.
