<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Stonehollow props" tilewidth="16" tileheight="16" tilecount="96" columns="16">
 <image source="../sheets/1x/stonehollow-props.png" width="256" height="96"/>
 <tile id="0"><animation><frame tileid="0" duration="600"/><frame tileid="1" duration="90"/><frame tileid="2" duration="90"/><frame tileid="3" duration="600"/></animation></tile>
 <tile id="4"><animation><frame tileid="4" duration="600"/><frame tileid="5" duration="110"/><frame tileid="6" duration="110"/><frame tileid="7" duration="600"/></animation></tile>
 <tile id="11"><animation><frame tileid="11" duration="800"/><frame tileid="12" duration="90"/><frame tileid="13" duration="90"/><frame tileid="14" duration="120"/><frame tileid="15" duration="600"/></animation></tile>
 <tile id="16"><animation><frame tileid="16" duration="800"/><frame tileid="17" duration="90"/><frame tileid="18" duration="90"/><frame tileid="19" duration="120"/><frame tileid="20" duration="600"/></animation></tile>
 <tile id="21"><animation><frame tileid="21" duration="110"/><frame tileid="22" duration="110"/><frame tileid="23" duration="110"/><frame tileid="24" duration="110"/><frame tileid="25" duration="110"/><frame tileid="26" duration="110"/></animation></tile>
 <tile id="27"><animation><frame tileid="27" duration="160"/><frame tileid="28" duration="160"/><frame tileid="29" duration="160"/><frame tileid="30" duration="160"/></animation></tile>
 <tile id="32"><animation><frame tileid="32" duration="200"/><frame tileid="33" duration="200"/><frame tileid="34" duration="200"/><frame tileid="35" duration="200"/></animation></tile>
 <tile id="36"><animation><frame tileid="36" duration="700"/><frame tileid="37" duration="80"/><frame tileid="38" duration="80"/><frame tileid="39" duration="650"/><frame tileid="40" duration="110"/></animation></tile>
 <tile id="64"><animation><frame tileid="64" duration="110"/><frame tileid="65" duration="110"/><frame tileid="66" duration="110"/><frame tileid="67" duration="110"/><frame tileid="68" duration="110"/><frame tileid="69" duration="110"/></animation></tile>
 <tile id="80"><animation><frame tileid="80" duration="110"/><frame tileid="81" duration="110"/><frame tileid="82" duration="110"/><frame tileid="83" duration="110"/><frame tileid="84" duration="110"/><frame tileid="85" duration="110"/></animation></tile>
</tileset>
