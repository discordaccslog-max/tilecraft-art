<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Effects 16×16" tilewidth="16" tileheight="16" tilecount="80" columns="20">
 <image source="../sheets/1x/effects-small.png" width="320" height="64"/>
 <tile id="0"><animation><frame tileid="0" duration="90"/><frame tileid="1" duration="90"/><frame tileid="2" duration="90"/><frame tileid="3" duration="90"/><frame tileid="4" duration="90"/><frame tileid="5" duration="90"/></animation></tile>
 <tile id="6"><animation><frame tileid="6" duration="90"/><frame tileid="7" duration="90"/><frame tileid="8" duration="90"/><frame tileid="9" duration="90"/><frame tileid="10" duration="90"/><frame tileid="11" duration="90"/></animation></tile>
 <tile id="12"><animation><frame tileid="12" duration="90"/><frame tileid="13" duration="90"/><frame tileid="14" duration="90"/><frame tileid="15" duration="90"/><frame tileid="16" duration="90"/><frame tileid="17" duration="90"/></animation></tile>
 <tile id="20"><animation><frame tileid="20" duration="90"/><frame tileid="21" duration="90"/><frame tileid="22" duration="90"/><frame tileid="23" duration="90"/><frame tileid="24" duration="90"/><frame tileid="25" duration="90"/></animation></tile>
 <tile id="40"><animation><frame tileid="40" duration="140"/><frame tileid="41" duration="140"/><frame tileid="42" duration="140"/><frame tileid="43" duration="140"/></animation></tile>
 <tile id="44"><animation><frame tileid="44" duration="140"/><frame tileid="45" duration="140"/><frame tileid="46" duration="140"/><frame tileid="47" duration="140"/></animation></tile>
 <tile id="48"><animation><frame tileid="48" duration="110"/><frame tileid="49" duration="110"/><frame tileid="50" duration="110"/><frame tileid="51" duration="110"/></animation></tile>
 <tile id="52"><animation><frame tileid="52" duration="160"/><frame tileid="53" duration="160"/><frame tileid="54" duration="160"/><frame tileid="55" duration="160"/></animation></tile>
</tileset>
