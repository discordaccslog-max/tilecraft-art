<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Meadowlands nature" tilewidth="16" tileheight="16" tilecount="128" columns="16">
 <image source="../sheets/1x/meadowlands-nature.png" width="256" height="128"/>
 <tile id="0"><animation><frame tileid="0" duration="200"/><frame tileid="1" duration="200"/><frame tileid="2" duration="200"/><frame tileid="3" duration="200"/></animation></tile>
 <tile id="4"><animation><frame tileid="4" duration="200"/><frame tileid="5" duration="200"/><frame tileid="6" duration="200"/><frame tileid="7" duration="200"/></animation></tile>
 <tile id="8"><animation><frame tileid="8" duration="200"/><frame tileid="9" duration="200"/><frame tileid="10" duration="200"/><frame tileid="11" duration="200"/></animation></tile>
 <tile id="12"><animation><frame tileid="12" duration="240"/><frame tileid="13" duration="240"/><frame tileid="14" duration="240"/><frame tileid="15" duration="240"/></animation></tile>
 <tile id="118"><animation><frame tileid="118" duration="110"/><frame tileid="119" duration="110"/><frame tileid="120" duration="110"/><frame tileid="121" duration="110"/></animation></tile>
 <tile id="122"><animation><frame tileid="122" duration="110"/><frame tileid="123" duration="110"/><frame tileid="124" duration="110"/><frame tileid="125" duration="110"/></animation></tile>
 <wangsets>
  <wangset name="Fence" type="edge" tile="95">
   <wangcolor name="Fence" color="#9c6538" tile="95" probability="1"/>
   <wangcolor name="Surroundings" color="#404060" tile="-1" probability="1"/>
   <wangtile tileid="80" wangid="2,0,2,0,2,0,2,0"/>
   <wangtile tileid="81" wangid="1,0,2,0,2,0,2,0"/>
   <wangtile tileid="82" wangid="2,0,1,0,2,0,2,0"/>
   <wangtile tileid="83" wangid="1,0,1,0,2,0,2,0"/>
   <wangtile tileid="84" wangid="2,0,2,0,1,0,2,0"/>
   <wangtile tileid="85" wangid="1,0,2,0,1,0,2,0"/>
   <wangtile tileid="86" wangid="2,0,1,0,1,0,2,0"/>
   <wangtile tileid="87" wangid="1,0,1,0,1,0,2,0"/>
   <wangtile tileid="88" wangid="2,0,2,0,2,0,1,0"/>
   <wangtile tileid="89" wangid="1,0,2,0,2,0,1,0"/>
   <wangtile tileid="90" wangid="2,0,1,0,2,0,1,0"/>
   <wangtile tileid="91" wangid="1,0,1,0,2,0,1,0"/>
   <wangtile tileid="92" wangid="2,0,2,0,1,0,1,0"/>
   <wangtile tileid="93" wangid="1,0,2,0,1,0,1,0"/>
   <wangtile tileid="94" wangid="2,0,1,0,1,0,1,0"/>
   <wangtile tileid="95" wangid="1,0,1,0,1,0,1,0"/>
  </wangset>
 </wangsets>
</tileset>
