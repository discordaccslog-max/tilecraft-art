<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Mossway sampler" tilewidth="16" tileheight="16" tilecount="40" columns="8">
 <image source="../sheets/1x/sample-sampler.png" width="128" height="80"/>
 <wangsets>
  <wangset name="Stepping stones" type="edge" tile="23">
   <wangcolor name="Stepping stones" color="#a0a6b4" tile="23" probability="1"/>
   <wangcolor name="Surroundings" color="#404060" tile="-1" probability="1"/>
   <wangtile tileid="8" wangid="2,0,2,0,2,0,2,0"/>
   <wangtile tileid="9" wangid="1,0,2,0,2,0,2,0"/>
   <wangtile tileid="10" wangid="2,0,1,0,2,0,2,0"/>
   <wangtile tileid="11" wangid="1,0,1,0,2,0,2,0"/>
   <wangtile tileid="12" wangid="2,0,2,0,1,0,2,0"/>
   <wangtile tileid="13" wangid="1,0,2,0,1,0,2,0"/>
   <wangtile tileid="14" wangid="2,0,1,0,1,0,2,0"/>
   <wangtile tileid="15" wangid="1,0,1,0,1,0,2,0"/>
   <wangtile tileid="16" wangid="2,0,2,0,2,0,1,0"/>
   <wangtile tileid="17" wangid="1,0,2,0,2,0,1,0"/>
   <wangtile tileid="18" wangid="2,0,1,0,2,0,1,0"/>
   <wangtile tileid="19" wangid="1,0,1,0,2,0,1,0"/>
   <wangtile tileid="20" wangid="2,0,2,0,1,0,1,0"/>
   <wangtile tileid="21" wangid="1,0,2,0,1,0,1,0"/>
   <wangtile tileid="22" wangid="2,0,1,0,1,0,1,0"/>
   <wangtile tileid="23" wangid="1,0,1,0,1,0,1,0"/>
  </wangset>
 </wangsets>
</tileset>
