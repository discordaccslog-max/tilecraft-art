<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Swamp terrain (Winter)" tilewidth="16" tileheight="16" tilecount="112" columns="16">
 <image source="../sheets/1x/four-seasons-swamp-winter.png" width="256" height="112"/>
 <tile id="16" probability="0"/>
 <tile id="64"><animation><frame tileid="64" duration="200"/><frame tileid="66" duration="200"/><frame tileid="68" duration="200"/><frame tileid="70" duration="200"/></animation></tile>
 <tile id="65"><animation><frame tileid="65" duration="200"/><frame tileid="67" duration="200"/><frame tileid="69" duration="200"/><frame tileid="71" duration="200"/></animation></tile>
 <tile id="73"><animation><frame tileid="73" duration="200"/><frame tileid="74" duration="200"/><frame tileid="75" duration="200"/><frame tileid="76" duration="200"/></animation></tile>
 <tile id="80"><animation><frame tileid="80" duration="200"/><frame tileid="82" duration="200"/><frame tileid="84" duration="200"/><frame tileid="86" duration="200"/></animation></tile>
 <tile id="81"><animation><frame tileid="81" duration="200"/><frame tileid="83" duration="200"/><frame tileid="85" duration="200"/><frame tileid="87" duration="200"/></animation></tile>
 <tile id="96"><animation><frame tileid="96" duration="200"/><frame tileid="98" duration="200"/><frame tileid="100" duration="200"/><frame tileid="102" duration="200"/></animation></tile>
 <tile id="97"><animation><frame tileid="97" duration="200"/><frame tileid="99" duration="200"/><frame tileid="101" duration="200"/><frame tileid="103" duration="200"/></animation></tile>
 <wangsets>
  <wangset name="Swamp mud" type="mixed" tile="62">
   <wangcolor name="Swamp mud" color="#30c0b0" tile="62" probability="1"/>
   <wangcolor name="Surroundings" color="#404060" tile="-1" probability="1"/>
   <wangtile tileid="16" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="17" wangid="1,2,2,2,2,2,2,2"/>
   <wangtile tileid="18" wangid="2,2,1,2,2,2,2,2"/>
   <wangtile tileid="19" wangid="1,2,1,2,2,2,2,2"/>
   <wangtile tileid="20" wangid="1,1,1,2,2,2,2,2"/>
   <wangtile tileid="21" wangid="2,2,2,2,1,2,2,2"/>
   <wangtile tileid="22" wangid="1,2,2,2,1,2,2,2"/>
   <wangtile tileid="23" wangid="2,2,1,2,1,2,2,2"/>
   <wangtile tileid="24" wangid="1,2,1,2,1,2,2,2"/>
   <wangtile tileid="25" wangid="1,1,1,2,1,2,2,2"/>
   <wangtile tileid="26" wangid="2,2,1,1,1,2,2,2"/>
   <wangtile tileid="27" wangid="1,2,1,1,1,2,2,2"/>
   <wangtile tileid="28" wangid="1,1,1,1,1,2,2,2"/>
   <wangtile tileid="29" wangid="2,2,2,2,2,2,1,2"/>
   <wangtile tileid="30" wangid="1,2,2,2,2,2,1,2"/>
   <wangtile tileid="31" wangid="2,2,1,2,2,2,1,2"/>
   <wangtile tileid="32" wangid="1,2,1,2,2,2,1,2"/>
   <wangtile tileid="33" wangid="1,1,1,2,2,2,1,2"/>
   <wangtile tileid="34" wangid="2,2,2,2,1,2,1,2"/>
   <wangtile tileid="35" wangid="1,2,2,2,1,2,1,2"/>
   <wangtile tileid="36" wangid="2,2,1,2,1,2,1,2"/>
   <wangtile tileid="37" wangid="1,2,1,2,1,2,1,2"/>
   <wangtile tileid="38" wangid="1,1,1,2,1,2,1,2"/>
   <wangtile tileid="39" wangid="2,2,1,1,1,2,1,2"/>
   <wangtile tileid="40" wangid="1,2,1,1,1,2,1,2"/>
   <wangtile tileid="41" wangid="1,1,1,1,1,2,1,2"/>
   <wangtile tileid="42" wangid="2,2,2,2,1,1,1,2"/>
   <wangtile tileid="43" wangid="1,2,2,2,1,1,1,2"/>
   <wangtile tileid="44" wangid="2,2,1,2,1,1,1,2"/>
   <wangtile tileid="45" wangid="1,2,1,2,1,1,1,2"/>
   <wangtile tileid="46" wangid="1,1,1,2,1,1,1,2"/>
   <wangtile tileid="47" wangid="2,2,1,1,1,1,1,2"/>
   <wangtile tileid="48" wangid="1,2,1,1,1,1,1,2"/>
   <wangtile tileid="49" wangid="1,1,1,1,1,1,1,2"/>
   <wangtile tileid="50" wangid="1,2,2,2,2,2,1,1"/>
   <wangtile tileid="51" wangid="1,2,1,2,2,2,1,1"/>
   <wangtile tileid="52" wangid="1,1,1,2,2,2,1,1"/>
   <wangtile tileid="53" wangid="1,2,2,2,1,2,1,1"/>
   <wangtile tileid="54" wangid="1,2,1,2,1,2,1,1"/>
   <wangtile tileid="55" wangid="1,1,1,2,1,2,1,1"/>
   <wangtile tileid="56" wangid="1,2,1,1,1,2,1,1"/>
   <wangtile tileid="57" wangid="1,1,1,1,1,2,1,1"/>
   <wangtile tileid="58" wangid="1,2,2,2,1,1,1,1"/>
   <wangtile tileid="59" wangid="1,2,1,2,1,1,1,1"/>
   <wangtile tileid="60" wangid="1,1,1,2,1,1,1,1"/>
   <wangtile tileid="61" wangid="1,2,1,1,1,1,1,1"/>
   <wangtile tileid="62" wangid="1,1,1,1,1,1,1,1"/>
  </wangset>
 </wangsets>
</tileset>
