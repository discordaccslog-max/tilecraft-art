<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Forest water (Winter)" tilewidth="16" tileheight="16" tilecount="192" columns="16">
 <image source="../sheets/1x/four-seasons-forest-water-winter.png" width="256" height="192"/>
 <tile id="0" probability="0"><animation><frame tileid="0" duration="230"/><frame tileid="1" duration="230"/><frame tileid="2" duration="230"/><frame tileid="3" duration="230"/></animation></tile>
 <tile id="4"><animation><frame tileid="4" duration="230"/><frame tileid="5" duration="230"/><frame tileid="6" duration="230"/><frame tileid="7" duration="230"/></animation></tile>
 <tile id="8"><animation><frame tileid="8" duration="230"/><frame tileid="9" duration="230"/><frame tileid="10" duration="230"/><frame tileid="11" duration="230"/></animation></tile>
 <tile id="12"><animation><frame tileid="12" duration="230"/><frame tileid="13" duration="230"/><frame tileid="14" duration="230"/><frame tileid="15" duration="230"/></animation></tile>
 <tile id="16"><animation><frame tileid="16" duration="230"/><frame tileid="17" duration="230"/><frame tileid="18" duration="230"/><frame tileid="19" duration="230"/></animation></tile>
 <tile id="20"><animation><frame tileid="20" duration="230"/><frame tileid="21" duration="230"/><frame tileid="22" duration="230"/><frame tileid="23" duration="230"/></animation></tile>
 <tile id="24"><animation><frame tileid="24" duration="230"/><frame tileid="25" duration="230"/><frame tileid="26" duration="230"/><frame tileid="27" duration="230"/></animation></tile>
 <tile id="28"><animation><frame tileid="28" duration="230"/><frame tileid="29" duration="230"/><frame tileid="30" duration="230"/><frame tileid="31" duration="230"/></animation></tile>
 <tile id="32"><animation><frame tileid="32" duration="230"/><frame tileid="33" duration="230"/><frame tileid="34" duration="230"/><frame tileid="35" duration="230"/></animation></tile>
 <tile id="36"><animation><frame tileid="36" duration="230"/><frame tileid="37" duration="230"/><frame tileid="38" duration="230"/><frame tileid="39" duration="230"/></animation></tile>
 <tile id="40"><animation><frame tileid="40" duration="230"/><frame tileid="41" duration="230"/><frame tileid="42" duration="230"/><frame tileid="43" duration="230"/></animation></tile>
 <tile id="44"><animation><frame tileid="44" duration="230"/><frame tileid="45" duration="230"/><frame tileid="46" duration="230"/><frame tileid="47" duration="230"/></animation></tile>
 <tile id="48"><animation><frame tileid="48" duration="230"/><frame tileid="49" duration="230"/><frame tileid="50" duration="230"/><frame tileid="51" duration="230"/></animation></tile>
 <tile id="52"><animation><frame tileid="52" duration="230"/><frame tileid="53" duration="230"/><frame tileid="54" duration="230"/><frame tileid="55" duration="230"/></animation></tile>
 <tile id="56"><animation><frame tileid="56" duration="230"/><frame tileid="57" duration="230"/><frame tileid="58" duration="230"/><frame tileid="59" duration="230"/></animation></tile>
 <tile id="60"><animation><frame tileid="60" duration="230"/><frame tileid="61" duration="230"/><frame tileid="62" duration="230"/><frame tileid="63" duration="230"/></animation></tile>
 <tile id="64"><animation><frame tileid="64" duration="230"/><frame tileid="65" duration="230"/><frame tileid="66" duration="230"/><frame tileid="67" duration="230"/></animation></tile>
 <tile id="68"><animation><frame tileid="68" duration="230"/><frame tileid="69" duration="230"/><frame tileid="70" duration="230"/><frame tileid="71" duration="230"/></animation></tile>
 <tile id="72"><animation><frame tileid="72" duration="230"/><frame tileid="73" duration="230"/><frame tileid="74" duration="230"/><frame tileid="75" duration="230"/></animation></tile>
 <tile id="76"><animation><frame tileid="76" duration="230"/><frame tileid="77" duration="230"/><frame tileid="78" duration="230"/><frame tileid="79" duration="230"/></animation></tile>
 <tile id="80"><animation><frame tileid="80" duration="230"/><frame tileid="81" duration="230"/><frame tileid="82" duration="230"/><frame tileid="83" duration="230"/></animation></tile>
 <tile id="84"><animation><frame tileid="84" duration="230"/><frame tileid="85" duration="230"/><frame tileid="86" duration="230"/><frame tileid="87" duration="230"/></animation></tile>
 <tile id="88"><animation><frame tileid="88" duration="230"/><frame tileid="89" duration="230"/><frame tileid="90" duration="230"/><frame tileid="91" duration="230"/></animation></tile>
 <tile id="92"><animation><frame tileid="92" duration="230"/><frame tileid="93" duration="230"/><frame tileid="94" duration="230"/><frame tileid="95" duration="230"/></animation></tile>
 <tile id="96"><animation><frame tileid="96" duration="230"/><frame tileid="97" duration="230"/><frame tileid="98" duration="230"/><frame tileid="99" duration="230"/></animation></tile>
 <tile id="100"><animation><frame tileid="100" duration="230"/><frame tileid="101" duration="230"/><frame tileid="102" duration="230"/><frame tileid="103" duration="230"/></animation></tile>
 <tile id="104"><animation><frame tileid="104" duration="230"/><frame tileid="105" duration="230"/><frame tileid="106" duration="230"/><frame tileid="107" duration="230"/></animation></tile>
 <tile id="108"><animation><frame tileid="108" duration="230"/><frame tileid="109" duration="230"/><frame tileid="110" duration="230"/><frame tileid="111" duration="230"/></animation></tile>
 <tile id="112"><animation><frame tileid="112" duration="230"/><frame tileid="113" duration="230"/><frame tileid="114" duration="230"/><frame tileid="115" duration="230"/></animation></tile>
 <tile id="116"><animation><frame tileid="116" duration="230"/><frame tileid="117" duration="230"/><frame tileid="118" duration="230"/><frame tileid="119" duration="230"/></animation></tile>
 <tile id="120"><animation><frame tileid="120" duration="230"/><frame tileid="121" duration="230"/><frame tileid="122" duration="230"/><frame tileid="123" duration="230"/></animation></tile>
 <tile id="124"><animation><frame tileid="124" duration="230"/><frame tileid="125" duration="230"/><frame tileid="126" duration="230"/><frame tileid="127" duration="230"/></animation></tile>
 <tile id="128"><animation><frame tileid="128" duration="230"/><frame tileid="129" duration="230"/><frame tileid="130" duration="230"/><frame tileid="131" duration="230"/></animation></tile>
 <tile id="132"><animation><frame tileid="132" duration="230"/><frame tileid="133" duration="230"/><frame tileid="134" duration="230"/><frame tileid="135" duration="230"/></animation></tile>
 <tile id="136"><animation><frame tileid="136" duration="230"/><frame tileid="137" duration="230"/><frame tileid="138" duration="230"/><frame tileid="139" duration="230"/></animation></tile>
 <tile id="140"><animation><frame tileid="140" duration="230"/><frame tileid="141" duration="230"/><frame tileid="142" duration="230"/><frame tileid="143" duration="230"/></animation></tile>
 <tile id="144"><animation><frame tileid="144" duration="230"/><frame tileid="145" duration="230"/><frame tileid="146" duration="230"/><frame tileid="147" duration="230"/></animation></tile>
 <tile id="148"><animation><frame tileid="148" duration="230"/><frame tileid="149" duration="230"/><frame tileid="150" duration="230"/><frame tileid="151" duration="230"/></animation></tile>
 <tile id="152"><animation><frame tileid="152" duration="230"/><frame tileid="153" duration="230"/><frame tileid="154" duration="230"/><frame tileid="155" duration="230"/></animation></tile>
 <tile id="156"><animation><frame tileid="156" duration="230"/><frame tileid="157" duration="230"/><frame tileid="158" duration="230"/><frame tileid="159" duration="230"/></animation></tile>
 <tile id="160"><animation><frame tileid="160" duration="230"/><frame tileid="161" duration="230"/><frame tileid="162" duration="230"/><frame tileid="163" duration="230"/></animation></tile>
 <tile id="164"><animation><frame tileid="164" duration="230"/><frame tileid="165" duration="230"/><frame tileid="166" duration="230"/><frame tileid="167" duration="230"/></animation></tile>
 <tile id="168"><animation><frame tileid="168" duration="230"/><frame tileid="169" duration="230"/><frame tileid="170" duration="230"/><frame tileid="171" duration="230"/></animation></tile>
 <tile id="172"><animation><frame tileid="172" duration="230"/><frame tileid="173" duration="230"/><frame tileid="174" duration="230"/><frame tileid="175" duration="230"/></animation></tile>
 <tile id="176"><animation><frame tileid="176" duration="230"/><frame tileid="177" duration="230"/><frame tileid="178" duration="230"/><frame tileid="179" duration="230"/></animation></tile>
 <tile id="180"><animation><frame tileid="180" duration="230"/><frame tileid="181" duration="230"/><frame tileid="182" duration="230"/><frame tileid="183" duration="230"/></animation></tile>
 <tile id="184"><animation><frame tileid="184" duration="230"/><frame tileid="185" duration="230"/><frame tileid="186" duration="230"/><frame tileid="187" duration="230"/></animation></tile>
 <wangsets>
  <wangset name="Forest stream" type="mixed" tile="184">
   <wangcolor name="Forest stream" color="#30c0b0" tile="184" probability="1"/>
   <wangcolor name="Surroundings" color="#404060" tile="-1" probability="1"/>
   <wangtile tileid="0" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="4" wangid="1,2,2,2,2,2,2,2"/>
   <wangtile tileid="8" wangid="2,2,1,2,2,2,2,2"/>
   <wangtile tileid="12" wangid="1,2,1,2,2,2,2,2"/>
   <wangtile tileid="16" wangid="1,1,1,2,2,2,2,2"/>
   <wangtile tileid="20" wangid="2,2,2,2,1,2,2,2"/>
   <wangtile tileid="24" wangid="1,2,2,2,1,2,2,2"/>
   <wangtile tileid="28" wangid="2,2,1,2,1,2,2,2"/>
   <wangtile tileid="32" wangid="1,2,1,2,1,2,2,2"/>
   <wangtile tileid="36" wangid="1,1,1,2,1,2,2,2"/>
   <wangtile tileid="40" wangid="2,2,1,1,1,2,2,2"/>
   <wangtile tileid="44" wangid="1,2,1,1,1,2,2,2"/>
   <wangtile tileid="48" wangid="1,1,1,1,1,2,2,2"/>
   <wangtile tileid="52" wangid="2,2,2,2,2,2,1,2"/>
   <wangtile tileid="56" wangid="1,2,2,2,2,2,1,2"/>
   <wangtile tileid="60" wangid="2,2,1,2,2,2,1,2"/>
   <wangtile tileid="64" wangid="1,2,1,2,2,2,1,2"/>
   <wangtile tileid="68" wangid="1,1,1,2,2,2,1,2"/>
   <wangtile tileid="72" wangid="2,2,2,2,1,2,1,2"/>
   <wangtile tileid="76" wangid="1,2,2,2,1,2,1,2"/>
   <wangtile tileid="80" wangid="2,2,1,2,1,2,1,2"/>
   <wangtile tileid="84" wangid="1,2,1,2,1,2,1,2"/>
   <wangtile tileid="88" wangid="1,1,1,2,1,2,1,2"/>
   <wangtile tileid="92" wangid="2,2,1,1,1,2,1,2"/>
   <wangtile tileid="96" wangid="1,2,1,1,1,2,1,2"/>
   <wangtile tileid="100" wangid="1,1,1,1,1,2,1,2"/>
   <wangtile tileid="104" wangid="2,2,2,2,1,1,1,2"/>
   <wangtile tileid="108" wangid="1,2,2,2,1,1,1,2"/>
   <wangtile tileid="112" wangid="2,2,1,2,1,1,1,2"/>
   <wangtile tileid="116" wangid="1,2,1,2,1,1,1,2"/>
   <wangtile tileid="120" wangid="1,1,1,2,1,1,1,2"/>
   <wangtile tileid="124" wangid="2,2,1,1,1,1,1,2"/>
   <wangtile tileid="128" wangid="1,2,1,1,1,1,1,2"/>
   <wangtile tileid="132" wangid="1,1,1,1,1,1,1,2"/>
   <wangtile tileid="136" wangid="1,2,2,2,2,2,1,1"/>
   <wangtile tileid="140" wangid="1,2,1,2,2,2,1,1"/>
   <wangtile tileid="144" wangid="1,1,1,2,2,2,1,1"/>
   <wangtile tileid="148" wangid="1,2,2,2,1,2,1,1"/>
   <wangtile tileid="152" wangid="1,2,1,2,1,2,1,1"/>
   <wangtile tileid="156" wangid="1,1,1,2,1,2,1,1"/>
   <wangtile tileid="160" wangid="1,2,1,1,1,2,1,1"/>
   <wangtile tileid="164" wangid="1,1,1,1,1,2,1,1"/>
   <wangtile tileid="168" wangid="1,2,2,2,1,1,1,1"/>
   <wangtile tileid="172" wangid="1,2,1,2,1,1,1,1"/>
   <wangtile tileid="176" wangid="1,1,1,2,1,1,1,1"/>
   <wangtile tileid="180" wangid="1,2,1,1,1,1,1,1"/>
   <wangtile tileid="184" wangid="1,1,1,1,1,1,1,1"/>
  </wangset>
 </wangsets>
</tileset>
